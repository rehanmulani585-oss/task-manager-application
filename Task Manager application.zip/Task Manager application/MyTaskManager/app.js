const fs = require('fs').promises;

const FILE_NAME = 'tasks.json';


// Load Tasks
async function loadTasks() {

    try {

        const data = await fs.readFile(FILE_NAME, 'utf8');

        return JSON.parse(data);

    } catch (error) {

        return [];

    }

}


// Save Tasks
async function saveTasks(tasks) {

    await fs.writeFile(
        FILE_NAME,
        JSON.stringify(tasks, null, 2)
    );

}


// Add Task
async function addTask(title, description) {

    const tasks = await loadTasks();

    const newTask = {

        id: Date.now(),

        title: title,

        description: description,

        status: "pending"

    };

    tasks.push(newTask);

    await saveTasks(tasks);

    console.log("Task Added Successfully");

}


// View Tasks
async function viewTasks() {

    const tasks = await loadTasks();

    console.log("\nAll Tasks:");

    console.log(tasks);

}


// Update Task
async function updateTask(id) {

    const tasks = await loadTasks();

    const task = tasks.find(t => t.id == id);

    if (task) {

        task.status = "completed";

        await saveTasks(tasks);

        console.log("Task Updated Successfully");

    } else {

        console.log("Task Not Found");

    }

}


// Delete Task
async function deleteTask(id) {

    const tasks = await loadTasks();

    const updatedTasks = tasks.filter(t => t.id != id);

    await saveTasks(updatedTasks);

    console.log("Task Deleted Successfully");

}



// Main Function
async function main() {

    // Add Tasks
    await addTask(
        "Study Node.js",
        "Practice fs module"
    );

    await addTask(
        "Complete Assignment",
        "Submit before Monday"
    );


    // View Tasks
    await viewTasks();


    // Load Tasks
    const tasks = await loadTasks();


    // Update First Task
    if (tasks.length > 0) {

        await updateTask(tasks[0].id);

    }


    // View Updated Tasks
    await viewTasks();


    // Delete Second Task
    if (tasks.length > 1) {

        await deleteTask(tasks[1].id);

    }


    // Final View
    await viewTasks();

}


main();